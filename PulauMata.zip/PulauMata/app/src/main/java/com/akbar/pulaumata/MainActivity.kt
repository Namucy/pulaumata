package com.akbar.pulaumata

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }
        root.addView(TextView(this).apply { text = "Pulau Mata 👀"; textSize = 26f })
        status = TextView(this).apply { textSize = 15f; setPadding(0, 24, 0, 24) }
        root.addView(status)
        fun btn(label: String, intent: () -> Intent) = root.addView(Button(this).apply {
            text = label
            setOnClickListener { startActivity(intent()) }
        })
        btn("1. Aktifkan layanan aksesibilitas") { Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS) }
        btn("2. Aktifkan akses notifikasi") { Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS) }
        btn("3. Baterai: tanpa batasan") { Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS) }
        btn("Info aplikasi (izinkan setelan terbatas)") {
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
        }
        root.addView(TextView(this).apply {
            textSize = 13f; setPadding(0, 32, 0, 0)
            text = "Jika tombol aksesibilitas/notifikasi abu-abu: buka Info aplikasi → titik tiga (⋮) → " +
                "\"Izinkan setelan terbatas\", lalu ulangi. Di HyperOS, aktifkan juga Autostart dan " +
                "kunci aplikasi di Recent Apps."
        })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        val acc = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
        val nl = Settings.Secure.getString(contentResolver, "enabled_notification_listeners").orEmpty()
        fun mark(ok: Boolean) = if (ok) "✅" else "❌"
        status.text = "${mark(acc.contains(packageName))} Aksesibilitas (pulau, app berjalan)\n" +
            "${mark(nl.contains(packageName))} Akses notifikasi (notifikasi, musik)"
    }
}
