package com.akbar.pulaumata

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.RingtoneManager
import android.media.session.MediaController
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import android.service.notification.StatusBarNotification
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.OvershootInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.content.res.ColorStateList

class IslandService : AccessibilityService() {

    companion object {
        var instance: IslandService? = null
        var controllers: List<MediaController> = emptyList()
        const val USE_BLUR = false // ubah ke true untuk mencoba blur latar asli (bisa terlihat persegi di sudut)
    }

    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private lateinit var island: FrameLayout
    private lateinit var lp: WindowManager.LayoutParams
    private var sizeAnim: ValueAnimator? = null
    private var currentKey = ""

    private var expanded = false
    private var tempView: View? = null
    private var tempKey = ""
    private var lastPkg = ""

    private var media: MediaController? = null
    private var timerEnd = 0L
    private var timerLabel: TextView? = null
    private var panelTimerLabel: TextView? = null

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- lifecycle ----------
    override fun onServiceConnected() {
        instance = this
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        island = FrameLayout(this).apply {
            background = GlassDrawable(resources.displayMetrics.density)
            setOnClickListener { toggleExpanded() }
        }
        lp = WindowManager.LayoutParams(
            dp(110), dp(32),
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(8) }
        if (USE_BLUR && Build.VERSION.SDK_INT >= 31) {
            lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_BLUR_BEHIND
            lp.blurBehindRadius = dp(24)
        }
        wm.addView(island, lp)

        val f = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(volumeReceiver, f, Context.RECEIVER_EXPORTED)
        else registerReceiver(volumeReceiver, f)

        applyMedia(controllers)
        refresh()
    }

    override fun onDestroy() {
        instance = null
        try { unregisterReceiver(volumeReceiver) } catch (_: Exception) {}
        try { wm.removeView(island) } catch (_: Exception) {}
        super.onDestroy()
    }

    override fun onInterrupt() {}

    // ---------- app berjalan ----------
    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (pkg == packageName || pkg == lastPkg) return
        if (pkg.startsWith("com.android.systemui") || pkg.contains("inputmethod") || pkg.contains("keyboard")) return
        lastPkg = pkg
        if (tempView != null && tempKey != "app") return
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (_: Exception) { pkg }
        showTemp("app", appIcon(pkg), label, -1, 1500)
    }

    // ---------- notifikasi ----------
    fun onNotif(sbn: StatusBarNotification) {
        val n = sbn.notification
        if (sbn.packageName == packageName || sbn.isOngoing) return
        if (n.flags and android.app.Notification.FLAG_GROUP_SUMMARY != 0) return
        val title = n.extras.getCharSequence(android.app.Notification.EXTRA_TITLE)?.toString() ?: return
        val text = n.extras.getCharSequence(android.app.Notification.EXTRA_TEXT)?.toString().orEmpty()
        val msg = if (text.isBlank()) title else "$title: $text"
        ui.post { showTemp("notif:" + sbn.key, appIcon(sbn.packageName), msg, -1, 4000) }
    }

    // ---------- volume ----------
    private val volumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            if (i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1) != AudioManager.STREAM_MUSIC) return
            val v = i.getIntExtra("android.media.EXTRA_VOLUME_STREAM_VALUE", 0)
            val max = (getSystemService(Context.AUDIO_SERVICE) as AudioManager).getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            val pct = if (max > 0) v * 100 / max else 0
            val view = tempView
            if (currentKey == "vol" && view != null) {
                view.findViewWithTag<ProgressBar>("bar")?.progress = pct
                view.findViewWithTag<TextView>("txt")?.text = "🔊 $pct%"
                scheduleTempClear(2000)
            } else showTemp("vol", null, "🔊 $pct%", pct, 2000)
        }
    }

    // ---------- musik ----------
    fun refreshMedia() { ui.post { applyMedia(controllers) } }

    private val mediaCb = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) { refresh() }
        override fun onMetadataChanged(metadata: MediaMetadata?) { refresh() }
    }

    private fun applyMedia(list: List<MediaController>) {
        media?.unregisterCallback(mediaCb)
        media = list.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING } ?: list.firstOrNull()
        media?.registerCallback(mediaCb)
        refresh()
    }

    private fun isPlaying() = media?.playbackState?.state == PlaybackState.STATE_PLAYING
    private fun songTitle() = media?.metadata?.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
    private fun songLine(): String {
        val t = songTitle()
        val a = media?.metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
        return if (a.isBlank()) t else "$t – $a"
    }
    private fun albumArt(): Drawable? =
        media?.metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)?.let { BitmapDrawable(resources, it) }

    // ---------- timer ----------
    private val ticker = object : Runnable {
        override fun run() {
            if (timerEnd == 0L) return
            val left = timerEnd - SystemClock.elapsedRealtime()
            if (left <= 0) { timerEnd = 0; timerLabel = null; panelTimerLabel = null; timerDone(); return }
            val s = (left + 999) / 1000
            val txt = "⏱ %02d:%02d".format(s / 60, s % 60)
            timerLabel?.text = txt
            panelTimerLabel?.text = txt
            ui.postDelayed(this, 500)
        }
    }

    private fun startTimer(min: Int) {
        timerEnd = SystemClock.elapsedRealtime() + min * 60_000L
        ui.removeCallbacks(ticker); ui.post(ticker); refresh()
    }

    private fun stopTimer() { timerEnd = 0; ui.removeCallbacks(ticker); refresh() }

    private fun timerDone() {
        try {
            val v = getSystemService(Vibrator::class.java)
            v.vibrate(VibrationEffect.createOneShot(800, VibrationEffect.DEFAULT_AMPLITUDE))
            RingtoneManager.getRingtone(this, RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)).play()
        } catch (_: Exception) {}
        showTemp("done", null, "⏰ Timer selesai!", -1, 5000)
    }

    // ---------- tampilan ----------
    private fun toggleExpanded() {
        expanded = !expanded
        ui.removeCallbacks(autoCollapse)
        if (expanded) ui.postDelayed(autoCollapse, 10_000)
        refresh()
    }
    private val autoCollapse = Runnable { expanded = false; refresh() }

    private val tempClear = Runnable { tempView = null; refresh() }
    private fun scheduleTempClear(ms: Long) { ui.removeCallbacks(tempClear); ui.postDelayed(tempClear, ms) }

    private fun showTemp(key: String, icon: Drawable?, text: String, progress: Int, ms: Long) {
        tempView = row(icon, text, progress)
        tempKey = key
        scheduleTempClear(ms)
        refresh()
    }

    private fun refresh() {
        timerLabel = null
        val timerOn = timerEnd > SystemClock.elapsedRealtime()
        val key: String
        val view: View
        val w: Int; val h: Int
        when {
            tempView != null -> { key = tempKey; view = tempView!!; w = dp(260); h = dp(44) }
            expanded -> {
                key = "panel:${songTitle()}:${isPlaying()}:$timerOn"
                if (key == currentKey) return
                view = panel(); w = dp(340); h = dp(176)
            }
            timerOn -> {
                key = "timer"
                if (key == currentKey) return
                view = row(null, "⏱ --:--", -1)
                timerLabel = view.findViewWithTag("txt")
                w = dp(150); h = dp(40)
            }
            isPlaying() && songTitle().isNotBlank() -> {
                key = "music:${songLine()}"
                if (key == currentKey) return
                view = row(albumArt(), songLine(), -1); w = dp(250); h = dp(44)
            }
            else -> {
                key = "idle"
                if (key == currentKey) return
                view = EyesView(this); w = dp(110); h = dp(32)
            }
        }
        if (key == currentKey && tempView != null) return
        currentKey = key
        island.removeAllViews()
        island.addView(view, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        view.alpha = 0f
        view.animate().alpha(1f).setDuration(200).start()
        morph(w, h)
        if (timerOn) { ui.removeCallbacks(ticker); ui.post(ticker) }
    }

    private fun morph(w: Int, h: Int) {
        sizeAnim?.cancel()
        val w0 = lp.width; val h0 = lp.height
        sizeAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = 300
            interpolator = OvershootInterpolator(0.9f)
            addUpdateListener {
                val t = it.animatedValue as Float
                lp.width = (w0 + (w - w0) * t).toInt()
                lp.height = (h0 + (h - h0) * t).toInt()
                try { wm.updateViewLayout(island, lp) } catch (_: Exception) {}
            }
            start()
        }
    }

    private fun appIcon(pkg: String): Drawable? = try { packageManager.getApplicationIcon(pkg) } catch (_: Exception) { null }

    private fun row(icon: Drawable?, text: String, progress: Int): View = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        setPadding(dp(12), 0, dp(14), 0)
        if (icon != null) addView(ImageView(context).apply { setImageDrawable(icon) },
            LinearLayout.LayoutParams(dp(26), dp(26)).apply { rightMargin = dp(10) })
        addView(TextView(context).apply {
            tag = "txt"; this.text = text; setTextColor(Color.WHITE); textSize = 13f; setShadowLayer(4f, 0f, 1f, 0x66000000)
            maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        if (progress >= 0) addView(ProgressBar(context, null, android.R.attr.progressBarStyleHorizontal).apply {
            tag = "bar"; max = 100; this.progress = progress
            progressTintList = ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = ColorStateList.valueOf(0x33FFFFFF)
        }, LinearLayout.LayoutParams(dp(80), dp(6)).apply { leftMargin = dp(8) })
    }

    private fun label(t: String, size: Float = 14f) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE)
        maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.END
    }

    private fun tapBtn(t: String, size: Float = 22f, onClick: () -> Unit) = TextView(this).apply {
        text = t; textSize = size; setTextColor(Color.WHITE); gravity = Gravity.CENTER
        setPadding(dp(14), dp(6), dp(14), dp(6))
        background = android.graphics.drawable.InsetDrawable(
            GradientDrawable().apply { setColor(0x22FFFFFF); cornerRadius = dp(18).toFloat() }, dp(3))
        setOnClickListener { onClick() }
    }

    private fun panel(): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(14), dp(18), dp(10))
        addView(label(if (songTitle().isBlank()) "♪ Tidak ada musik" else "♪ ${songLine()}"))
        addView(LinearLayout(context).apply {
            gravity = Gravity.CENTER
            addView(tapBtn("⏮") { media?.transportControls?.skipToPrevious() })
            addView(tapBtn(if (isPlaying()) "⏸" else "▶", 26f) {
                if (isPlaying()) media?.transportControls?.pause() else media?.transportControls?.play()
            })
            addView(tapBtn("⏭") { media?.transportControls?.skipToNext() })
        })
        val tl = label(if (timerEnd > SystemClock.elapsedRealtime()) "⏱ --:--" else "⏱ Timer", 13f)
        panelTimerLabel = tl
        addView(tl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        addView(LinearLayout(context).apply {
            gravity = Gravity.CENTER
            for (m in intArrayOf(1, 5, 10)) addView(tapBtn("${m}m", 15f) { startTimer(m) })
            addView(tapBtn("Stop", 15f) { stopTimer() })
        })
    }
}
