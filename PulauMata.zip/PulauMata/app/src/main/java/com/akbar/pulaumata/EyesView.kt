package com.akbar.pulaumata

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.view.View
import kotlin.random.Random

/** Sepasang mata lucu: berkedip dan melirik acak saat idle. */
class EyesView(c: Context) : View(c) {
    private val white = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
    private val pupil = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF111111.toInt() }
    private var look = 0f
    private var blink = 1f
    private val h = Handler(Looper.getMainLooper())
    private val loop = object : Runnable {
        override fun run() {
            if (Random.nextInt(3) == 0) doBlink() else lookTo(Random.nextFloat() * 2 - 1)
            h.postDelayed(this, Random.nextLong(1800, 4200))
        }
    }

    override fun onAttachedToWindow() { super.onAttachedToWindow(); h.postDelayed(loop, 1200) }
    override fun onDetachedFromWindow() { h.removeCallbacks(loop); super.onDetachedFromWindow() }

    private fun doBlink() {
        ValueAnimator.ofFloat(1f, 0.08f, 1f).apply {
            duration = 220
            addUpdateListener { blink = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun lookTo(t: Float) {
        ValueAnimator.ofFloat(look, t).apply {
            duration = 260
            addUpdateListener { look = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val hh = height.toFloat()
        val ew = w * 0.2f
        val eh = hh * 0.62f * blink
        for (cx in floatArrayOf(w * 0.34f, w * 0.66f)) {
            c.drawOval(cx - ew / 2, hh / 2 - eh / 2, cx + ew / 2, hh / 2 + eh / 2, white)
            if (blink > 0.4f) {
                val r = ew * 0.3f
                val px = cx + look * ew * 0.2f
                c.drawCircle(px, hh / 2, r, pupil)
                c.drawCircle(px - r * 0.3f, hh / 2 - r * 0.3f, r * 0.3f, white)
            }
        }
    }
}
