package com.akbar.pulaumata

import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable

/** Latar kaca ala "liquid glass": isi tembus pandang, kilau di atas, dan tepi bercahaya. */
class GlassDrawable(private val d: Float) : Drawable() {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x8C0B0F14.toInt() }
    private val sheen = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 1.3f * d }
    private val rect = RectF()

    override fun onBoundsChange(b: Rect) {
        sheen.shader = LinearGradient(
            0f, b.top.toFloat(), 0f, b.bottom.toFloat(),
            intArrayOf(0x45FFFFFF, 0x0DFFFFFF, 0x00FFFFFF), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
        stroke.shader = LinearGradient(
            b.left.toFloat(), b.top.toFloat(), b.right.toFloat(), b.bottom.toFloat(),
            intArrayOf(0xE6FFFFFF.toInt(), 0x26FFFFFF, 0x8CFFFFFF.toInt()), floatArrayOf(0f, 0.5f, 1f), Shader.TileMode.CLAMP
        )
    }

    override fun draw(c: Canvas) {
        val b = bounds
        val i = stroke.strokeWidth / 2
        rect.set(b.left + i, b.top + i, b.right - i, b.bottom - i)
        val r = minOf(rect.height() / 2, 32f * d)
        c.drawRoundRect(rect, r, r, fill)
        c.drawRoundRect(rect, r, r, sheen)
        c.drawRoundRect(rect, r, r, stroke)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(cf: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
