package com.akbar.pulaumata

import android.content.ComponentName
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class NotifListener : NotificationListenerService() {
    private val msm by lazy { getSystemService(MediaSessionManager::class.java) }
    private val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { push(it) }

    override fun onListenerConnected() {
        val cn = ComponentName(this, NotifListener::class.java)
        try {
            msm.addOnActiveSessionsChangedListener(sessionListener, cn)
            push(msm.getActiveSessions(cn))
        } catch (_: SecurityException) {}
    }

    override fun onListenerDisconnected() {
        try { msm.removeOnActiveSessionsChangedListener(sessionListener) } catch (_: Exception) {}
    }

    private fun push(list: List<MediaController>?) {
        IslandService.controllers = list.orEmpty()
        IslandService.instance?.refreshMedia()
    }

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        IslandService.instance?.onNotif(sbn)
    }
}
